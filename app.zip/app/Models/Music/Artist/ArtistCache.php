<?php

namespace App\Models\Music\Artist;

use App\Models\Music\Artist\Artist;
use Cache;
use Carbon\Carbon;

class ArtistCache
{
	public function get($id)
	{
		$time = Carbon::now()->addMonth();
		$key = config('music.key') . '.artists.' . $id;

		$artist = Cache::remember($key, $time, function() use ($id) {
					$artist = Artist::findOrFail($id);
					return $artist->load('media', 'tracks');
				});

		return $artist;
	}

	public function clear($id)
	{
		$key = config('music.key') . '.artists.' . $id;

		Cache::forget($key);
	}
}