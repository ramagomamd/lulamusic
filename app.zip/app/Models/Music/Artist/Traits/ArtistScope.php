<?php

namespace App\Models\Music\Artist\Traits;

trait ArtistScope
{
	
}