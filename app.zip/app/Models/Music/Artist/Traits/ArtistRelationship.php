<?php

namespace App\Models\Music\Artist\Traits;

trait ArtistRelationship
{
	public function tracks()
	{
		return $this->belongsToMany(config('music.track.model'));
	}
}