<?php

namespace App\Models\Music\Artist;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Artist\Traits\ArtistAttribute;
use App\Models\Music\Artist\Traits\ArtistRelationship;
use App\Models\Music\Artist\Traits\ArtistScope;
use Illuminate\Database\Eloquent\SoftDeletes;
use Plank\Mediable\Mediable;

class Artist extends Model
{
    use ArtistAttribute,
    	ArtistRelationship,
    	ArtistScope,
    	SoftDeletes,
    	Mediable;

    const UNKNOWN_ID = 1;
    const UNKNOWN_NAME = 'Unknown Artist';
    const VARIOUS_ID = 2;
    const VARIOUS_NAME = 'Various Artists';

    protected $guarded = ['id'];

    protected $fillable = ['name', 'slug', 'bio'];

    protected $dates = ['deleted_at'];
}
