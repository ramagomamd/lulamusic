<?php

namespace App\Models\Music\Track\Traits;

trait TrackAttribute
{
	public function getShowButtonAttribute()
    {
        return '<a href="'.route('admin.music.tracks.show', $this).'" class="btn btn-xs btn-info"><i class="fa fa-search" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.view').'"></i></a> ';
    }

     /**
     * @return string
     */
    public function getEditButtonAttribute()
    {
        return '<a href="'.route('admin.music.tracks.edit', $this).'" class="btn btn-xs btn-primary"><i class="fa fa-edit" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.edit').'"></i></a> ';
    }

    /**
     * @return string
     */
    public function getDeleteButtonAttribute()
    {
        return '<a href="'.route('admin.music.tracks.destroy', $this).'"
             data-method="delete"
             data-trans-button-cancel="'.trans('buttons.general.cancel').'"
             data-trans-button-confirm="'.trans('buttons.general.crud.delete').'"
             data-trans-title="'.trans('strings.backend.general.are_you_sure').'"
             class="btn btn-xs btn-danger"><i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.delete').'"></i></a> ';
    }

    /**
     * @return string
     */
    public function getDeleteActionAttribute()
    {
        return '<a href="'.route('admin.music.tracks.destroy', $this).'"
             data-method="delete"
             data-trans-button-cancel="'.trans('buttons.general.cancel').'"
             data-trans-button-confirm="'.trans('buttons.general.crud.delete').'"
             data-trans-title="'.trans('strings.backend.general.are_you_sure').'"
             class="btn btn-md btn-danger"><i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.delete').'"></i> Delete</a> ';
    }

    /**
     * @return string
     */
    public function getActionButtonsAttribute()
    {
    	return
            $this->getShowButtonAttribute().
            $this->getEditButtonAttribute().
            $this->getDeleteButtonAttribute();
    }

    public function getTitleAttribute($value)
    {
        return title_case($value);
    }

    public function getBitrateAttribute($value)
    {
        $value =  (integer) ($value/1000);

        return  $value . ' kbps';
    }

    public function getFileAttribute()
    {
        if ($file = $this->firstMedia('file')) {
            return $file;
        }
        return null;
    }

    public function getCoverAttribute()
    {
        if ($cover = $this->firstMedia('cover')) {
            return $cover;
        }  
        return null;
    }

    public function getFullTitleAttribute()
    {
        return $this->artists_title_comma . ' - ' . $this->title . $this->features_title_comma;
    }

    public function getBelongsToAttribute()
    {
        if ($this->trackable_type == 'albums') {
            $route = route('admin.music.' . $this->trackable_type . '.show', 
                $this->trackable->id);
            return '
                <tr>
                    <td><strong>' . title_case(str_singular($this->trackable_type)) . '
                    </strong></td>
                    <td><span>
                    <a href="' . $route . '">'
                        . $this->trackable->title . 
                    '</a>
                    </span></td>
                </tr>';
        } elseif ($this->trackable_type == 'singles') {
            $route = route('admin.music.' . $this->trackable_type . '.index');
            return '
                <tr>
                    <td><strong> On:
                    </strong></td>
                    <td><span>
                    <a href="' . $route . '"> '
                        . title_case($this->trackable_type) . 
                    '</a>
                    </span></td>
                </tr>';
        } 
        return null; 
    }

    public function getArtistsCommaAttribute()
    {
        if ($this->artists) {
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'main';
            });

            if ($artists->count() > 1) {
                $links = [];
                foreach ($artists as $artist) {
                    $links[] = '<a href="'.route('admin.music.artists.show', $artist->id).'"> '.$artist->name.'</a>';
                }

                if (collect($links)->count() == 2) {

                    $artists = implode(' and ', $links); 

                    return $artists . $this->features_comma;
                } else {

                    $last = array_pop($links); 
                    $artists = implode(', ', $links); 
                    $artists .= ' and '.$last; 

                    return $artists . $this->features_comma;
                }
            } elseif ($artists->count() == 1) {
                    return '<a href="'.route('admin.music.artists.show', $artists->first()->id).'"> '.$artists->first()->name.'</a>' 
                        . $this->features_comma;
            }

        } else {
            return null;
        }
    }

    public function getArtistsTitleCommaAttribute()
    {
        if ($this->artists) {
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'main';
            });

            if ($artists->count() > 1) {
                $titles = [];
                foreach ($artists as $artist) {
                    $titles[] = $artist->name;
                }

                if (collect($titles)->count() == 2) {

                    $artists = implode(' and ', $titles); 

                    return $artists;
                } else {

                    $last = array_pop($titles); 
                    $artists = implode(', ', $titles); 
                    $artists .= ' and '.$last; 

                    return $artists;
                }
            } elseif ($artists->count() == 1) {
                    return $artists->first()->name;
            }

        } else {
            return null;
        }
    }

    public function getAlbumArtistAttribute()
    {
        if (isset($this->trackable->artist->name) && !empty($this->trackable->artist->name)) {
            return
                '<a href="'.route('admin.music.artists.show', $this->trackable->artist->id).'">'
                .$this->trackable->artist->name.'</a>';
        } else {
            return '<a href="' . route('frontend.index') . '"> ' . 'LulaMusic' . '</a>';
        }
    }

    public function getComposersCommaAttribute()
    {
        if ($this->artists) {
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'composer';
            });

            if ($artists->count() > 1) {
                $links = [];
                foreach ($artists as $artist) {
                    $links[] = '<a href="'.route('admin.music.artists.show', $artist->id).'"> '.$artist->name.'</a>';
                }

                if (collect($links)->count() == 2) {

                    $artists = implode(' and ', $links); 

                    return $artists;
                } else {

                    $last = array_pop($links); 
                    $artists = implode(', ', $links); 
                    $artists .= ' and '.$last; 

                    return $artists;
                }
            } elseif ($artists->count() == 1) {
                    return '<a href="'.route('admin.music.artists.show', $artists->first()->id).'"> '.$artists->first()->name.'</a>';
            }

        } else {
            return null;
        }
    }

    public function getFeaturesCommaAttribute()
    {
        if ($this->artists) {
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'feature';
            });

            if($artists->count() > 1) {
                $links = [];
                foreach ($artists as $artist) {
                    $links[] = '<a href="'.route('admin.music.artists.show', $artist->id).'"> ' .$artist->name. '</a>';
                }

                if (collect($links)->count() == 2) {

                    $artists = implode(' and ', $links); 

                    return ' ft ' . $artists;
                } else {

                    $last = array_pop($links); 
                    $artists = implode(', ', $links); 
                    $artists .= ' and ' . $last; 

                    return ' ft ' .$artists;
                }
            } elseif( $artists->count() == 1) {
                return ' ft <a href="'.route('admin.music.artists.show', $artists->first()->id).'"> '.$artists->first()->name.'</a>';
            }
            
        } else {
            return null;
        }
    }

    public function getFeaturesTitleCommaAttribute()
    {
        if ($this->artists) {
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'feature';
            });

            if($artists->count() > 1) {
                $links = [];
                foreach ($artists as $artist) {
                    $links[] = $artist->name;
                }

                if (collect($links)->count() == 2) {

                    $artists = implode(' and ', $links); 

                    return ' ft ' . $artists;
                } else {

                    $last = array_pop($links); 
                    $artists = implode(', ', $links); 
                    $artists .= ' and ' . $last; 

                    return ' ft ' .$artists;
                }
            } elseif( $artists->count() == 1) {
                return ' ft ' .$artists->first()->name;
            }
            
        } else {
            return null;
        }
    }

    

    public function getFeaturesAttribute()
    {
        if ($this->artists->count() > 1) {
            $features = [];
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'feature';
            });

            foreach($artists as $artist) {
                $features[] = $artist->name;
            }

            return collect($features)->implode(',');

        } elseif ($this->artists->count() == 1) {
            if($this->artists->first()->pivot->role == 'feature') {
                return $this->artists->first()->name;
            }
        } else {
            return null;
        }
    }

    public function getArtistNamesAttribute()
    {
        if ($this->artists->count() > 1) {
            $main = [];
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'main';
            });

            foreach($artists as $artist) {
                $main[] = $artist->name;
            }

            return collect($main)->implode(',');

        } elseif ($this->artists->count() == 1) {
            if($this->artists->first()->pivot->role == 'main') {
                return $this->artists->first()->name;
            }
        } else {
            return null;
        }
    }

    public function getArtistDashAttribute()
    {
        if ($this->artists->count() > 1) {
            $main = [];
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'main';
            });

            foreach($artists as $artist) {
                $main[] = $artist->name;
            }

            return collect($main)->implode('-');

        } elseif ($this->artists->count() == 1) {
            if($this->artists->first()->pivot->role == 'main') {
                return $this->artists->first()->name;
            }
        } else {
            return null;
        }
    }

    public function getFeaturesDashAttribute()
    {
        if ($this->artists->count() > 1) {
            $features = [];
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'feature';
            });

            foreach($artists as $artist) {
                $features[] = $artist->name;
            }

            return collect($features)->implode('-');

        } elseif ($this->artists->count() == 1) {
            if($this->artists->first()->pivot->role == 'feature') {
                return $this->artists->first()->name;
            }
        } else {
            return null;
        }
    }

    public function getComposersAttribute()
    {
        if ($this->artists->count() > 1) {
            $composers = [];
            $artists = $this->artists->reject(function($artist) {
                return $artist->pivot->role != 'composer';
            });

            foreach($artists as $artist) {
                $composers[] = $artist->name;
            }

            return collect($composers)->implode(',');

        } elseif ($this->artists->count() == 1) {
            if($this->artists->first()->pivot->role == 'composer') {
                return $this->artists->first()->name;
            }
        } else {
            return null;
        }
    }

    public function getPathAttribute()
    {
        return $this->file->getAbsolutePath();
    }

}