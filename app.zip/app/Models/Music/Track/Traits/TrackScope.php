<?php

namespace App\Models\Music\Track\Traits;

trait TrackScope
{
	public function scopeFindSimilarTitles($query, $title)
	{
		return $query->where('title', $title)->get();
	}

	public function scopeFindSimilarSlugs($query, $slug)
	{
		return $query->where('slug', $slug)->get();
	}
}