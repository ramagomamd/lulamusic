<?php

namespace App\Models\Music\Track;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Track\Traits\TrackAttribute;
use App\Models\Music\Track\Traits\TrackRelationship;
use App\Models\Music\Track\Traits\TrackScope;
use Illuminate\Database\Eloquent\SoftDeletes;
use Plank\Mediable\Mediable;

class Track extends Model
{
    use TrackAttribute,
    	TrackRelationship,
    	TrackScope,
    	SoftDeletes,
    	Mediable;

    protected $fillable = [
    			'title', 'slug', 'year', 'number', 
    			'comment', 'album', 'composer', 
    			'bitrate', 'duration', 'copyright'
    ];

    protected $dates = ['deleted_at'];
}
