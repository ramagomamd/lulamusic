<?php

namespace App\Models\Music\Track;

use App\Models\Music\Track\Track;
use Cache;
use Carbon\Carbon;

class TrackCache
{
	public function get($id)
	{
		$time = Carbon::now()->addMonth();
		$key = config('music.key') . '.tracks.' . $id;

		$track = Cache::remember($key, $time, function() use ($id) {
					$track = Track::findOrFail($id);
					return $track->load('media', 'artists', 'trackable.genres', 'trackable.categories');
				});

		return $track;
	}

	public function clear($id)
	{
		$key = config('music.key') . '.tracks.' . $id;

		Cache::forget($key);
	}
}