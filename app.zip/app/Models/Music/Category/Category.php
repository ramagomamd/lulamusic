<?php

namespace App\Models\Music\Category;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Category\Traits\CategoryAttribute;
use App\Models\Music\Category\Traits\CategoryRelationship;
use App\Models\Music\Category\Traits\CategoryScope;
use Kalnoy\Nestedset\NodeTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use CategoryAttribute;
    use CategoryRelationship,
    	CategoryScope,
    	NodeTrait,
    	SoftDeletes;

    protected $fillable = ['_lft', '_rgt', 'parent_id', 'name', 'slug', 'description'];

    protected $dates = ['deleted_at'];
}
