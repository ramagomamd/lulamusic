<?php

namespace App\Models\Music\Category\Traits;

trait CategoryRelationship
{
	public function albums()
	{
		return $this->morphedByMany(config('music.album.model'), 'categorable')
					->withPivot('is_main');
	}

	public function singles()
	{
		return $this->morphedByMany(config('music.single.model'), 'categorable')
					->withPivot('is_main');
	}
}