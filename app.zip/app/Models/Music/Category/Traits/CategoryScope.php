<?php

namespace App\Models\Music\Category\Traits;

trait CategoryScope
{
	
}