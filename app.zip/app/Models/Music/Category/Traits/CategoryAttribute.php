<?php

namespace App\Models\Music\Category\Traits;

trait CategoryAttribute
{
	public function getShowButtonAttribute()
    {
        return '<a href="'.route('admin.music.categories.show', $this).'" class="btn btn-xs btn-info"><i class="fa fa-search" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.view').'"></i></a> ';
    }

     /**
     * @return string
     */
    public function getEditButtonAttribute()
    {
        return '<a href="'.route('admin.music.categories.edit', $this).'" class="btn btn-xs btn-primary"><i class="fa fa-edit" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.edit').'"></i></a> ';
    }

    /**
     * @return string
     */
    public function getDeleteButtonAttribute()
    {
        return '<a href="'.route('admin.music.categories.destroy', $this).'"
             data-method="delete"
             data-trans-button-cancel="'.trans('buttons.general.cancel').'"
             data-trans-button-confirm="'.trans('buttons.general.crud.delete').'"
             data-trans-title="'.trans('strings.backend.general.are_you_sure').'"
             class="btn btn-xs btn-danger"><i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.delete').'"></i></a> ';
    }

    /**
     * @return string
     */
    public function getDeleteActionAttribute()
    {
        return '<a href="'.route('admin.music.categories.destroy', $this).'"
             data-method="delete"
             data-trans-button-cancel="'.trans('buttons.general.cancel').'"
             data-trans-button-confirm="'.trans('buttons.general.crud.delete').'"
             data-trans-title="'.trans('strings.backend.general.are_you_sure').'"
             class="btn btn-md btn-danger"><i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.delete').'"></i> Delete</a> ';
    }

    /**
     * @return string
     */
    public function getActionButtonsAttribute()
    {
    	return
            $this->getShowButtonAttribute().
            $this->getEditButtonAttribute().
            $this->getDeleteButtonAttribute();
    }

    public function getNameAttribute($value)
    {
        return title_case($value);
    }

    public function hasAncestors()
    {
        return $this->parent_id != null;
    }

    public function getParentsAttribute()
    {
        if ($this->hasAncestors()) {
            $parents = $this->ancestors;

            return view('backend.music.categories.ancestors', compact('parents'));
        }
        return null;
    }

    public function hasDescendants()
    {
        return $this->descendants->isNotEmpty();
    }

    public function getChildrensAttribute()
    {
        if ($this->hasDescendants()) {
            $children = $this->descendants;

            return view('backend.music.categories.descendants', compact('children'));
        }
    }

    public function getSingleListsAttribute()
    {
        $singles = $this->singles()->with('tracks.artists', 'genres', 'categories')
                ->latest()->simplePaginate(10);

        return view('backend.music.singles.list', compact('singles'));
    }

    public function getAlbumListsAttribute()
    {
        $albums = $this->albums()->with('artist', 'genres', 'categories')
                ->latest()->simplePaginate(10);

        return view('backend.music.albums.list', compact('albums'));
    }
}