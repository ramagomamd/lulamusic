<?php

namespace App\Models\Music\Category;

use App\Models\Music\Category\Category;
use Cache;
use Carbon\Carbon;

class CategoryCache
{
	public function get($id)
	{
		$time = Carbon::now()->addMonth();
		$key = config('music.key') . '.categories.' . $id;

		$category = Cache::remember($key, $time, function() use ($id) {
					$category = Category::findOrFail($id);
					return $category->load('parent', 'children');
				});

		return $category;
	}

	public function clear($id)
	{
		$key = config('music.key') . '.categories.' . $id;

		Cache::forget($key);
	}
}