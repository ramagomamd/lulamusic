<?php

namespace App\Models\Music\Genre\Traits;

trait GenreRelationship
{
	public function albums()
	{
		return $this->morphedByMany(config('music.album.model'), 'genreable')
					->withPivot('is_main');
	}

	public function singles()
	{
		return $this->morphedByMany(config('music.single.model'), 'genreable')
					->withPivot('is_main');
	}
}