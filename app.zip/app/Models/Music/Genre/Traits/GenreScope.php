<?php

namespace App\Models\Music\Genre\Traits;

trait GenreScope
{
	
}