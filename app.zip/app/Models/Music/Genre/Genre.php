<?php

namespace App\Models\Music\Genre;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Genre\Traits\GenreAttribute;
use App\Models\Music\Genre\Traits\GenreRelationship;
use App\Models\Music\Genre\Traits\GenreScope;
use Illuminate\Database\Eloquent\SoftDeletes;
use Plank\Mediable\Mediable;

class Genre extends Model
{
    use GenreAttribute,
    	GenreRelationship,
    	GenreScope,
    	SoftDeletes,
        Mediable;

    protected $fillable = ['name', 'slug', 'description'];

    protected $dates = ['deleted_at'];
}
