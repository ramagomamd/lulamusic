<?php

namespace App\Models\Music\Genre;

use App\Models\Music\Genre\Genre;
use Cache;
use Carbon\Carbon;

class GenreCache
{
	public function get($id)
	{
		$time = Carbon::now()->addMonth();
		$key = config('music.key') . '.genres.' . $id;

		$genre = Cache::remember($key, $time, function() use ($id) {
					$genre = Genre::findOrFail($id);
					return $genre->load('media');
				});

		return $genre;
	}

	public function clear($id)
	{
		$key = config('music.key') . '.genres.' . $id;

		Cache::forget($key);
	}
}