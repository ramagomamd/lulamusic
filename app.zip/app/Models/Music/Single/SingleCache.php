<?php

namespace App\Models\Music\Single;

use App\Models\Music\Single\Single;
use Cache;
use Carbon\Carbon;

class SingleCache
{
	public function get($id)
	{
		$time = Carbon::now()->addMonth();
		$key = config('music.key') . '.singles.' . $id;

		$single = Cache::remember($key, $time, function() use ($id) {
					$single = Single::findOrFail($id);
					return $single->load('media', 'tracks.artists', 'categories', 'genres');
				});

		return $single;
	}

	public function clear($id)
	{
		$key = config('music.key') . '.singles.' . $id;

		Cache::forget($key);
	}
}