<?php

namespace App\Models\Music\Single;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Single\Traits\SingleAttribute;
use App\Models\Music\Single\Traits\SingleRelationship;
use App\Models\Music\Single\Traits\SingleScope;
use Illuminate\Database\Eloquent\SoftDeletes;
use Plank\Mediable\Mediable;

class Single extends Model
{
    use SingleAttribute,
    	SingleRelationship,
    	SingleScope,
    	SoftDeletes,
    	Mediable;

    protected $fillable = ['status'];

    protected $dates = ['deleted_at'];
}
