<?php

namespace App\Models\Music\Single\Traits;

trait SingleRelationship
{
	public function categories()
	{
		return $this->morphToMany(config('music.category.model'), 'categorable')
					->withPivot('is_main');;
	}

	public function genres()
	{
		return $this->morphToMany(config('music.genre.model'), 'genreable')
					->withPivot('is_main');;
	}
	
	public function tracks()
	{
		return $this->morphMany(config('music.track.model'), 'trackable');
	}
}