<?php

namespace App\Models\Music\Single\Traits;

trait SingleScope
{
	
}