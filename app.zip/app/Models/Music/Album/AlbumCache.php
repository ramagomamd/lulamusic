<?php

namespace App\Models\Music\Album;

use App\Models\Music\Album\Album;
use Cache;
use Carbon\Carbon;

class AlbumCache
{	
	public function get($id)
	{
		$time = Carbon::now()->addMonth();
		$key = config('music.key') . '.albums.' . $id;

		$album = Cache::remember($key, $time, function() use ($id) {
					$album = Album::findOrFail($id);
					return $album->load('media', 'tracks.artists', 'artist', 'categories', 'genres');
				});

		return $album;
	}

	public function clear($id)
	{
		$key = config('music.key') . '.albums.' . $id;

		Cache::forget($key);
	}
}