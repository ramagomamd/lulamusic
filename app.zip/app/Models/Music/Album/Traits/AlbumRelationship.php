<?php

namespace App\Models\Music\Album\Traits;

trait AlbumRelationship
{
	public function categories()
	{
		return $this->morphToMany(config('music.category.model'), 'categorable')
					->withPivot('is_main');
	}

	public function genres()
	{
		return $this->morphToMany(config('music.genre.model'), 'genreable')
					->withPivot('is_main');
	}

	public function artist()
	{
		return $this->belongsTo(config('music.artist.model'));
	}

	public function tracks()
	{
		return $this->morphMany(config('music.track.model'), 'trackable');
	}
}