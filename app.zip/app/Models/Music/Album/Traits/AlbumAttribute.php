<?php

namespace App\Models\Music\Album\Traits;

trait AlbumAttribute 
{
	public function getShowButtonAttribute()
    {
        return '<a href="'.route('admin.music.albums.show', $this).'" class="btn btn-xs btn-info"><i class="fa fa-search" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.view').'"></i></a> ';
    }

     /**
     * @return string
     */
    public function getEditButtonAttribute()
    {
        return '<a href="'.route('admin.music.albums.edit', $this).'" class="btn btn-xs btn-primary"><i class="fa fa-edit" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.edit').'"></i></a> ';
    }

    /**
     * @return string
     */
    public function getDeleteButtonAttribute()
    {
        return '<a href="'.route('admin.music.albums.destroy', $this).'"
             data-method="delete"
             data-trans-button-cancel="'.trans('buttons.general.cancel').'"
             data-trans-button-confirm="'.trans('buttons.general.crud.delete').'"
             data-trans-title="'.trans('strings.backend.general.are_you_sure').'"
             class="btn btn-xs btn-danger"><i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.delete').'"></i></a> ';
    }

    /**
     * @return string
     */
    public function getDeleteActionAttribute()
    {
        return '<a href="'.route('admin.music.albums.destroy', $this).'"
             data-method="delete"
             data-trans-button-cancel="'.trans('buttons.general.cancel').'"
             data-trans-button-confirm="'.trans('buttons.general.crud.delete').'"
             data-trans-title="'.trans('strings.backend.general.are_you_sure').'"
             class="btn btn-md btn-danger"><i class="fa fa-trash" data-toggle="tooltip" data-placement="top" title="'.trans('buttons.general.crud.delete').'"></i> Delete</a> ';
    }


    /**
     * @return string
     */
    public function getActionButtonsAttribute()
    {
    	return
            $this->getShowButtonAttribute().
            $this->getEditButtonAttribute().
            $this->getDeleteButtonAttribute();
    }

    public function getTitleAttribute($value)
    {
        return title_case($value);
    }

    public function getFullTitleAttribute()
    {
        return $this->artist->name . ' - ' . $this->title;
    }

    public function getTracksListAttribute()
    {
        $tracks = $this->tracks()->with('artists', 'trackable')->latest()->paginate(10);

        return view('backend.music.albums.tracks', compact('tracks'));
    }

    public function getCoverAttribute()
    {
        if ($cover = $this->firstMedia('cover')) {
            return $cover;
        }
        return null;
    }

    public function getCategoryAttribute()
    {
        if ($categories = $this->categories) {
            return $categories->last();
        }
        return null;
    }

    //  Artist Name for use during editing inputs
    public function getArtistNameAttribute()
    {
        return $this->artist->name;
    }

    public function getFullSlugAttribute()
    {
        return str_slug($this->artist->name . ' - ' . $this->title);
    }

    public function getCategoryLinksAttribute()
    {
        if ($this->categories->count() > 1) {
            $links = [];
            if ($this->main_category) {
                $categories = $this->categories->reject(function($category) {
                            return $category == $this->main_category;
                        });
                $main = '<a href="'.route('admin.music.categories.show', $this->main_category->id).'"> <strong>' .
                        $this->main_category->name . '</strong></a>';
            } else {
                $categories = $this->categories;
                $main = null;
            }
            
            foreach ($categories as $category) {
                $links[] = '<a href="'.route('admin.music.categories.show', $category->id).'"> ' .
                        $category->name . '</a>';
            }
            
            if (!is_null($main)) {
                $links = array_prepend($links, $main); 
            }

            $last = array_pop($links);
            $categories = implode(', ', $links);
            $categories .= ' and '.$last;

            return $categories; 
            
        } elseif($this->categories->count() === 1) {
            return '<a href="'.route('admin.music.categories.show', 
                $this->categories->first()->id).'"> <strong>' .
                $this->categories->first()->name.'</strong></a>';
        } else {
            return null;
        }
    }

    // For use in the Album  Index 
    public function getCategoryNamesAttribute()
    {
        if ($this->categories->count() > 1) {
            if ($this->main_category) {
                $categories = $this->categories->reject(function($category) {
                            return $category == $this->main_category;
                        });
                $main = $this->main_category->name;
            } else {
                $categories = $this->categories;
                $main = null;
            }

            $names = [];
            foreach($categories as $category) {
                $names[] = $category->name;
            }

            if (!is_null($main)) {
                $names = array_prepend($names, $main); 
            }

            $names = implode(',', $names);
            return $names;

        } elseif ($this->categories->count() == 1) {
            return $this->categories->first()->name;
        } else {
            return null;
        }
    }

    // For editing inputs purpose
    public function getGenreNamesAttribute()
    {
        if ($this->genres->count() > 1) {
            if ($this->main_genre) {
                $genres = $this->genres->reject(function($genre) {
                            return $genre == $this->main_genre;
                        });
                $main = $this->main_genre->name;
            } else {
                $genres = $this->genres;
                $main = null;
            }

            $names = [];
            foreach($genres as $genre) {
                $names[] = $genre->name;
            }

            if (!is_null($main)) {
                $names = array_prepend($names, $main); 
            }

            $names = implode(',', $names);
            return $names;

        } elseif ($this->genres->count() == 1) {
            return $this->genres->first()->name;
        } else {
            return null;
        }
    }

    public function getMainGenreAttribute()
    {
        $genre = $this->genres->first(function($genre) {
            return $genre->pivot->is_main;
        });

        return $genre;
    }

    public function getMainCategoryAttribute()
    {
        $category = $this->categories->first(function($category) {
            return $category->pivot->is_main;
        });

        return $category;
    }

    public function getGenreLinksAttribute()
    {
        if ($this->genres->count() > 1) {
            if ($this->main_genre) {
                $genres = $this->genres->reject(function($genre) {
                            return $genre == $this->main_genre;
                        });
                $main = '<a href="'.route('admin.music.genres.show', $this->main_genre->id).'"> <strong>' .
                        $this->main_genre->name . '</strong></a>';
            } else {
                $genres = $this->genres;
                $main = null;
            }
            
            $links = [];
            foreach ($genres as $genre) {
                $links[] = '<a href="'.route('admin.music.genres.show', $genre->id).'"> ' .
                        $genre->name . '</a>';
            }
            
            if (!is_null($main)) {
                $links = array_prepend($links, $main); 
            }

            $last = array_pop($links);
            $genres = implode(', ', $links);
            $genres .= ' and '.$last;

            return $genres; 

        } elseif($this->genres->count() === 1) {
            return '<a href="'.route('admin.music.genres.show', 
                $this->genres->first()->id).'"> <strong>' .
                $this->genres->first()->name.'</strong></a>';
        } else {
            return null;
        }
    }

    public function getZipAttribute()
    {
        return $this->getMedia('zip')->first();
    }
}