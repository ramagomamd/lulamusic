<?php

namespace App\Models\Music\Album;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Album\Traits\AlbumAttribute;
use App\Models\Music\Album\Traits\AlbumRelationship;
use App\Models\Music\Album\Traits\AlbumScope;
use Illuminate\Database\Eloquent\SoftDeletes;
use Plank\Mediable\Mediable;

class Album extends Model
{
    use AlbumAttribute,
    	AlbumRelationship,
    	AlbumScope,
    	SoftDeletes,
    	Mediable;

    protected $fillable = ['artist_id', 'title', 'slug', 'description', 'status'];

    protected $dates = ['deleted_at'];
}
