<?php 

namespace App\Repositories\Backend\Music;

use App\Repositories\BaseRepository;
use App\Models\Music\Category\Category;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Events\Backend\Music\Category\CategoryCreated;
use App\Events\Backend\Music\Category\CategoryUpdated;
use App\Events\Backend\Music\Category\CategoryDeleted;

class CategoryRepository extends BaseRepository
{
	const MODEL = Category::class;

	public function create(array $input)
	{
		$category = $this->createCategoryStub($input);

		DB::transaction(function () use ($category, $input) {
			if(isset($input['category_id'])) {
				$category->parent_id = $input['category_id'];
			}

			if($category->save()) {
				event(new CategoryCreated($category));

				return true;
			}

			throw new GeneralException(trans('exceptions.backend.music.categories.create_error'));
		});

		return $category;
	}

	public function update(Model $category, array $input)
	{
		$this->checkCategoryByName($category, $input['name']);
		$this->checkCategoryBySlug($category, $input['slug']);

		$category->name = $input['name'];
		$category->slug = (isset($input['slug']) ? $input['slug'] : str_slug($input['name']));
		$category->description = $input['description'];

		DB::transaction(function () use ($category, $input) {
			if(isset($input['category_id'])) {
				$category->parent_id = $input['category_id'];
			}

			if($category->save()) {
				event(new CategoryUpdated($category));

				return true;
			}

			throw new GeneralException(trans('exceptions.backend.music.categories.update_error'));
		});

		return $category;
	}

	public function delete(Model $category)
	{
		if ($category->delete()) {
			event(new CategoryDeleted($category));

			return true;
		}

		throw new GeneralException(trans('exceptions.backend.music.categories.delete_error'));
		
	}

	/**
     * @param  $name
     * @param  $category
     *
     * @throws GeneralException
     */
    protected function checkCategoryByName($category, $name)
    {
        //Figure out if name is not the same
        if ($category->name != $name) {
            //Check to see if name exists
            if ($this->query()->where('name', '=', $name)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.categories.category_error'));
            }
        }
    }

    /**
     * @param  $slug
     * @param  $category
     *
     * @throws GeneralException
     */
    protected function checkCategoryBySlug($category, $slug)
    {
        //Figure out if slug is not the same
        if ($category->slug != $slug) {
            //Check to see if slug exists
            if ($this->query()->where('slug', '=', $slug)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.categories.slug_error'));
            }
        }
    }

	public function createCategoryStub($data)
	{
		$category = self::MODEL;
		$category = new $category;
		$category->name = $data['name'];
		$category->slug = (isset($data['slug']) ? $data['slug'] : str_slug($data['name']));
		$category->description = $data['description'];

		return $category;
	}
}