<?php 

namespace App\Repositories\Backend\Music;

use App\Helpers\Validators\Mimes;
use MediaUploader;
use File;

class UploadRepository
{
	protected $validate;

	public function __construct(Mimes $validate)
	{
		$this->validate = $validate;
	}

	public function audio($file, $tags, $disk, $directory)
	{
		if (!$this->validate->audio($file)) return false;

		if ($tags['artists'] && $tags['title']) {
			$artists = explode(',', $tags['artists']);
			$artists = implode('-', $artists);
		} elseif (is_null($tags['artists']) && $tags['title']) {
			$artists = 'unknown';
		} else {
			return false;
		}

		$title = preg_replace("/[^A-Za-z0-9]/", "", $tags['title']);

		$title = $artists. '-' . $title;

		$media = MediaUploader::fromSource($file)
				->toDestination($disk, $directory)
				->useFilename($title)
				->upload();

		if ($media) {
			return $media;
		}
		return false;
	}

	public function image($file, $disk, $directory)
	{
		if (!$this->validate->image($file)) return false;

		$media = MediaUploader::fromSource($file)
				->toDestination($disk, $directory)
				->useHashForFilename()
				->upload();

		if ($media) {
			return $media;
		}
		return false;
	}

	public function zip($file, $filename, $disk, $directory)
	{
		$media = MediaUploader::fromSource($file)
				->setAllowedAggregateTypes(['archive'])
				->setMaximumSize(300000000)
				->useFilename($filename)
				->toDestination($disk, $directory)
				->upload();

		if ($media) {
			return $media;
		}
		return false;
	}

	public function import($disk, $directory, $filename, $extension)
	{
		$media = MediaUploader::import($disk, $directory, $filename, $extension);
		if ($media)
			return $media;
		return false;      
	}
}