<?php 

namespace App\Repositories\Backend\Music;

use App\Repositories\BaseRepository;
use App\Models\Music\Artist\Artist;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Models\Music\Album\Album;
use App\Models\Music\Track\Track;
use App\Repositories\Backend\Music\UploadRepository;

class ArtistRepository extends BaseRepository
{
	const MODEL = Artist::class;

	protected $upload;

	public function __construct(UploadRepository $upload)
	{
		$this->upload = $upload;
	}

	public function firstOrCreate($names)
	{
		if ($names) {
			// Create Artist Entity or Fetch One
			$artists = [];
			foreach (explode(',', $names) as $name) {
				$artist = $this->query()->firstOrCreate(['slug' => str_slug($name)], 
															['name' => $name]);
				$artists[$artist->id] = $artist->id;
			}
			
			return collect($artists);
		}
		return false;
	}

	public function createOne($name)
	{
		$artist = $this->query()->firstOrCreate(['slug' => str_slug($name)], ['name' => $name]);
		return $artist;
	}

	public function create(array $input)
	{
		$artist = $this->createArtistStub($input);

		DB::transaction(function () use ($artist, $input) {
			if($artist->save()) {

				if (isset($input['image'])) {
					$image = $this->upload->image(
									$input['image'], 'uploads', $this->directory($artist)
							);

					if ($image) {
						$artist->attachMedia($image, 'image');
					}
				}

				return true;
			}

			throw new GeneralException(trans('exceptions.backend.music.artists.create_error'));
		});

		return $artist;
	}

	public function update(Model $artist, array $input)
	{
		$this->checkArtistByName($artist, $input['name']);
		$this->checkArtistBySlug($artist, $input['slug']);

		$artist->name = $input['name'];
		$artist->slug = (isset($input['slug']) ? $input['slug'] : str_slug($input['name']));
		$artist->bio = $input['bio'];

		DB::transaction(function () use ($artist, $input) {
			if($artist->save()) {

				if (isset($input['image'])) {
					if ($artist->image) {
						$artist->image->delete();
					}

					if (isset($input['image'])) {
						$image = $this->upload->image(
										$input['image'], 'uploads', $this->directory($artist)
								);
						
						if ($image) {
							$artist->syncMedia($image, 'image');
						}
					}
				}

				return true;
			}

			throw new GeneralException(trans('exceptions.backend.music.artists.update_error'));
		});

		return $artist;
	}

	public function directory(Model $artist)
	{
		$title = title_case($artist->name);

		return 'music/covers/artists/'. $title;
	}

	public function createArtistStub($input)
	{
		$artist = self::MODEL;
		$artist = new $artist;

		$artist->name = $input['name'];
		$artist->slug = (isset($input['slug']) ? $input['slug'] : str_slug($input['name']));
		$artist->bio = $input['bio'];

		return $artist;
	}

	/**
     * @param  $name
     * @param  $artist
     *
     * @throws GeneralException
     */
    protected function checkArtistByName(Model $artist, $name)
    {
        //Figure out if name is not the same
        if ($artist->name != $name) {
            //Check to see if name exists
            if ($this->query()->where('name', '=', $name)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.artists.name_error'));
            }
        }
    }

    /**
     * @param  $slug
     * @param  $artist
     *
     * @throws GeneralException
     */
    protected function checkArtistBySlug(Model $artist, $slug)
    {
        //Figure out if slug is not the same
        if ($artist->slug != $slug) {
            //Check to see if slug exists
            if ($this->query()->where('slug', '=', $slug)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.artists.slug_error'));
            }
        }
    }

    public function albums(Model $artist)
    {
    	return Album::whereHas('artist', function($q) use ($artist) {
            $q->where('artist_id', $artist->id);
        });
    }

    public function delete(Model $artist)
    {
    	$artist->delete();
    }
}