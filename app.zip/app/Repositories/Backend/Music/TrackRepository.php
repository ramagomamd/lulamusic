<?php 

namespace App\Repositories\Backend\Music;

use Illuminate\Database\Eloquent\Model;
use App\Models\Music\Artist\Artist;
use Illuminate\Support\Facades\DB;
use App\Repositories\BaseRepository;
use App\Models\Music\Track\Track;
use App\Exceptions\GeneralException;
use App\Repositories\Backend\Music\UploadRepository;
use Illuminate\Http\UploadedFile;
use SplFileInfo;
use App\Services\Music\Tags;
use Storage;

class TrackRepository extends BaseRepository
{
	const MODEL = Track::class;

	protected $artists;
	protected $upload;

	public function __construct(ArtistRepository $artists, UploadRepository $upload)
	{
		$this->artists = $artists;
		$this->upload = $upload;
	}

	public function create($tags, $media, Model $model)
	{
		// Make A Track Model and Save
		$track = $this->createTrackStub($tags);

		if ($track) {

			if ($model->tracks()->save($track)) {
				// Create Artist Entity or Fetch One
				$artists = $this->artists->firstOrCreate($tags['artists']);
				if ($artists) {
					$artists->each(function($artist) use ($track) {
						$track->artists()->attach($artist);
					});
				} else {
					$track->artists()->attach(Artist::UNKNOWN_ID);
				}

				// Create Composers Entity And Attach Them
				if (isset($tags['composer'])) {
					$composers = $this->artists->firstOrCreate($tags['composer']);
					$track->artists()->attach($composers, ['role' => 'composer']);
				}

				// Attach Media To Track
				$track->attachMedia($media, 'file');

				// If Cover was Uploaded, save it and Attach to Track
				if (isset($tags['cover']) && !empty($tags['cover']['data'])) {
					$cover = $this->generateCover($tags['cover'], $track);
					if ($cover)
						$track->attachMedia($cover, 'cover');
				}

				$slug = str_slug($track->full_title);
				if ($this->query()->findSimilarSlugs($slug)->isNotEmpty()) {
					$slug = $slug . '-' . uniqid();
					$track->update(['slug' => $slug]);
				}
				$track->update(['slug' => $slug]); 

				return $track;
			}
			return false;
		}
		return false;
	}

	public function update(Model $model, $input)
	{
		DB::transaction(function() use ($model, $input) {
			$file = $model->file;
			// Update Track Model
			$track = $this->updateTrackStub($model, $input);

			if ($model->trackable->tracks()->save($model)) {
				// Update Track Cover
				if (isset($input['cover']) && $input['cover']->isValid()) {
					$data = $input['cover'];
					if ($model->cover) {
						$model->cover->forceDelete();
					}

					$directory = $this->generateCoverPath($file);
					$cover = $this->upload->image($data, 'uploads', $directory);
					$model->syncMedia($cover, 'cover');
				}

				$model->artists()->detach();

				// Create Artist Entity or Fetch One
				if(isset($input['artist_names']) && !empty($input['artist_names'])) {
					$artists = $this->artists->firstOrCreate($input['artist_names']);
					$model->artists()->attach($artists);
				}

				if (isset($input['features']) && !empty($input['features'])) {
					$features = $this->artists->firstOrCreate($input['features']);
					$model->artists()->attach($features, ['role' => 'feature']);
				}

				// If Main Artist & Features is not set, Use Unknown Artist
				if ($model->artists->isEmpty()) {
					$track->artists()->attach(Artist::UNKNOWN_ID);
				}

				if (isset($input['composers']) && !empty($input['composers'])) {
					$composers = $this->artists->firstOrCreate($input['composers']);
					$model->artists()->attach($composers, ['role' => 'composer']);
				}

				// Update File Tags
				$path = $file->getAbsolutePath();
				$file = $path instanceof SplFileInfo ? $path : new SplFileInfo($path);
				$file = new UploadedFile($file->getRealPath(), true);
				$tags = (new Tags($file))->setInfo($track);
			}
		});

		return $model;
	}

	public function updateTrackStub(Model $track, $input)
	{
		$title = title_case($input['title']);

		//Figure out if title is not the same
		if ($track->title != $title) {
			if ($this->query()->findSimilarTitles($title)->isNotEmpty())
				throw new GeneralException(
							trans('exceptions.backend.music.tracks.title_error')
				);
		}		

		$track->title = $title;
		$track->year = $input['year'];
		$track->number = $input['number'];
		if (isset($input['comment'])) {
			$track->comment = $input['comment'];
		} else {
			$track->comment = 'Downloaded Free From www.lulamusic.com';
		}
		if (isset($input['copyright'])) {
			$track->copyright = $input['copyright'];
		}

		return $track;
	}

	public function createTrackStub($tags)
	{
		$title = $tags['title'];

		if (!is_null($title) && isset($tags['duration'])) {
			if ($this->query()->findSimilarTitles($title)->isNotEmpty())
				$title = $title . '_' . uniqid();

			$track = self::MODEL;
			$track = new $track;

			$track->title = $title;
			$track->year = $tags['year'];
			$track->number = $tags['number'];
			if (isset($tags['comment'])) {
				$track->comment = $tags['comment'];
			} else {
				$track->comment = 'Downloaded Free From www.lulamusic.com';
			}
			$track->bitrate = $tags['bitrate'];
			$track->duration = $tags['duration'];
			if (isset($tags['copyright'])) {
				$track->copyright = $tags['copyright'];
			}
			
			return $track;
		} else {
			return false;
		}
	}

	/**
     * Generate a cover from provided data.
     */
    public function generateCover(array $cover, Model $track)
    {
        $extension = explode('/', $cover['image_mime']);
        $extension = empty($extension[1]) ? 'png' : $extension[1];

        $cover = $this->writeCoverFile($cover['data'], $extension, $track);

        return $cover;
    }

    /**
     * Write a cover image file with binary data and update the Album with the new cover file.
     *
     * @param string $binaryData
     * @param string $extension  The file extension
     */
    public function writeCoverFile($binaryData, $extension, Model $track)
    {
    	$file = $track->file;
        $extension = trim(strtolower($extension), '. ');
        $directory = $this->generateCoverPath($file);

        $store = Storage::disk($file->disk)
        	->put($directory . '/' .  $file->filename . '.' . $extension, $binaryData);

        if ($store) {
        	$cover = $this->upload
        		->import($file->disk, $directory, $file->filename, $extension);

        	return $cover;
        }
        return false;    
    }

    /**
     * Generate a random path for the cover image.
     *
     * @param string $extension The extension of the cover (without dot)
     *
     * @return string
     */
    private function generateCoverPath($file)
    {
        return $file->directory . '/covers';
    }

    public function delete(Model $track)
    {
    	$track->delete();
    }
}