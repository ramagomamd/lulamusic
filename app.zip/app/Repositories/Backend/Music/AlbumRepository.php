<?php 

namespace App\Repositories\Backend\Music;

use App\Repositories\BaseRepository;
use App\Models\Music\Album\Album;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Events\Backend\Music\Album\AlbumCreated;
use App\Events\Backend\Music\Album\AlbumUpdated;
use App\Events\Backend\Music\Album\AlbumDeleted;
use App\Exceptions\GeneralException;
use App\Repositories\Backend\Music\TrackRepository;
use App\Services\Music\Tags;
use App\Repositories\Backend\Music\UploadRepository;
use Symfony\Component\HttpFoundation\File\File;
use Illuminate\Http\UploadedFile;
use SplFileInfo;
use Download;
use Storage;


class AlbumRepository extends BaseRepository
{
	const MODEL = Album::class;

	protected $tracks;
	protected $artists;
	protected $genres;
	protected $upload;

	public function __construct(TrackRepository $tracks, ArtistRepository $artists, 
								GenreRepository $genres, UploadRepository $upload)
	{
		$this->tracks = $tracks;
		$this->artists = $artists;
		$this->genres = $genres;
		$this->upload = $upload;
	}

	public function create(array $input)
	{
		$album = $this->createAlbumStub($input);

		// Create Artist Entity or Fetch One
		$artist = $this->artists->createOne($input['artist']);
		$album->artist_id = $artist->id;

		DB::transaction(function () use ($album, $input) {
			if($album->save()) {
				// Create and Attach Categories
				$categories = $input['categories'];
				$album->categories()->attach($categories);

				// Sync Main Category
				$main_category = $input['main_category'];
				$album->categories()->syncWithoutDetaching($main_category);
				$album->categories()->updateExistingPivot($main_category, 
															['is_main' => true]);

				// Create and Attach Genres
				$genres = $this->genres->firstOrCreate($input['genres']);
				$album->genres()->attach($genres);

				// Sync Main Genre
				$main_genre = $input['main_genre'];
				$album->genres()->syncWithoutDetaching($main_genre);
				$album->genres()->updateExistingPivot($main_genre, ['is_main' => true]);

				if (isset($input['cover'])) {
					$cover = $this->upload->image(
									$input['cover'], 'uploads', $this->directory($album));

					$album->attachMedia($cover, 'cover');
				} 

				$slug = str_slug($album->full_title);
				if ($this->query()->findSimilarSlugs($slug)->isNotEmpty()) {
					throw new GeneralException(trans(
							'exceptions.backend.music.albums.album_exists'));
				} 
				$album->update(['slug' => $slug]);

				event(new AlbumCreated($album));

				return true;
			}

			throw new GeneralException(trans(
							'exceptions.backend.music.albums.create_error'));
		});

		return $album;

	}

	public function upload(array $data)
	{
		$files = $data['tracks'];
		$album = $this->query()->findOrFail($data['album_id']);

		if ($files && $album) {
			foreach ($files as $file) {
				// Fetch files ID3 Tags
				if (!$tags = (new Tags($file))->getInfo())
					continue;

				$media = $this->upload->audio($file, $tags, 'uploads', 
												$this->directory($album));
				if (!$media) continue;

				$track = $this->tracks->create($tags, $media, $album);
				if (!$track) continue;
				// Sync ID3 Tags To Model Instance
				$tags = (new Tags($file))->setInfo($track);
			}
			
			if ($album->tracks->isNotEmpty()) {
				// Create  new Zip File  and  Delete old  one
				$compress = Download::from($album);
				if ($compress) {
					$file = $compress instanceof SplFileInfo ? $compress : new SplFileInfo($compress);
					$file = new File($file->getRealPath());
					$filename = $album->slug . '-full-zipped-album';
					if ($file) {
						$zip = $this->upload
									->zip($file, $filename, 'uploads', $this->directory($album));
						unlink($file);
					}
					
					if ($zip) {
						if ($zipped = $album->getMedia('zip')->first()) {
							$zipped->forceDelete();
						}

						$album->syncMedia($zip, 'zip');
					}
				}
			}
			
			return $album;		
		}
		throw new GeneralException(trans('exceptions.backend.music.albums.upload_error'));	
	}

	public function directory(Model $album)
	{
		$category = title_case($album->main_category->name);
		$genre  =  title_case($album->main_genre->name);
		$title = title_case($album->full_title);

		return 'music/' . $category . '/' . $genre . '/albums/'. $title;
	}

	public function update(Model $album, array $input)
	{
		// Create Artist Entity or Fetch One
		$artist = $this->artists->createOne($input['artist_name']);
		$album->artist_id = $artist->id;

		$album->title = $input['title'];
		$album->slug = (isset($input['slug']) ? $input['slug'] : str_slug($input['title']));
		$album->description = $input['description'];

		DB::transaction(function () use ($album, $input) {
			if($album->save()) {
				// Sync Categories
				$categories = $input['categories'];
				$album->categories()->sync($categories);

				// Sync Main Category
				$main_category = $input['main_category'];
				$album->categories()->syncWithoutDetaching($main_category);
				$album->categories()->updateExistingPivot($main_category, 
															['is_main' => true]);
				
				// Create and Syn Genres
				$genres = $this->genres->firstOrCreate($input['genre_names']);
				$album->genres()->sync($genres);

				// Sync Main Genre
				$main_genre = $input['main_genre'];
				$album->genres()->syncWithoutDetaching($main_genre);
				$album->genres()->updateExistingPivot($main_genre, ['is_main' => true]);

				$file = $input['cover'];
				if (isset($file) && $file->isValid()) {
					if ($album->cover) {
						$album->cover->delete();
					}

					$cover = $this->upload->image($file, 'uploads', 
												$this->directory($album));
					if ($cover) {
						$album->syncMedia($cover, 'cover');
					}
				}

				$slug = str_slug($album->full_title);
				//Figure out if slug is not the same
		        if ($album->slug != $slug) {
		            //Check to see if slug exists and abort if so
					if ($this->query()->findSimilarSlugs($slug)->isNotEmpty()) {
						throw new GeneralException(trans(
								'exceptions.backend.music.albums.album_exists'));
					} 
					$album->update(['slug' => $slug]);
				}
				
				event(new AlbumUpdated($album));

				return true;
			}

			throw new GeneralException(trans(
								'exceptions.backend.music.albums.update_error'));
		});

		if ($tracks = $album->tracks) {
			$tracks->each(function($track) {
				$file = $track->file->getAbsolutePath();
				$file = $file instanceof SplFileInfo ? $file : new SplFileInfo($file);
				$file = new UploadedFile($file->getRealPath(), true);
				$tags = (new Tags($file))->setInfo($track);
			});
		}

		return $album;
	}

	public function delete(Model $album)
	{
		if ($album->delete()) {
			event(new AlbumDeleted($album));

			return true;
		}

		throw new GeneralException(trans('exceptions.backend.music.albums.delete_error'));
		
	}

	/**
     * @param  $title
     * @param  $album
     *
     * @throws GeneralException
     */
    protected function checkAlbumByTitle(Model $album, $title)
    {
        //Figure out if title is not the same
        if ($album->title != $title) {
            //Check to see if title exists
            if ($this->query()->where('title', '=', $title)->first()) {
                throw new GeneralException(trans(
                				'exceptions.backend.music.albums.title_error'));
            }
        }
    }

    /**
     * @param  $slug
     * @param  $album
     *
     * @throws GeneralException
     */
    protected function checkAlbumBySlug(Model $album, $slug)
    {
        //Figure out if slug is not the same
        if ($album->slug != $slug) {
            //Check to see if slug exists
            if ($this->query()->where('slug', '=', $slug)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.albums.slug_error'));
            }
        }
    }

	public function createAlbumStub($input)
	{
		$album = self::MODEL;
		$album = new $album;
		$album->title = $input['title'];
		$album->description = $input['description'];
		
		return $album;
	}

	public function inGenre($genre)
    {
        return $this->query()->whereHas('genres', function($q) use ($genre) {
            $q->where('genre_id', $genre);
        })->paginate();
    }
}