<?php 

namespace App\Repositories\Backend\Music;

use App\Repositories\BaseRepository;
use App\Models\Music\Genre\Genre;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use MediaUploader;

class GenreRepository extends BaseRepository
{
	const MODEL = Genre::class;

	public function firstOrCreate($names)
	{
		$genres = [];
		foreach (explode(',', $names) as $name) {
			$genre = $this->query()->firstOrCreate(['slug' => str_slug($name)], ['name' => $name]);
			$genres[$genre->id] = $genre->id;
		}

		return collect($genres);
	}

	public function createOne($name)
	{
		$genre = $this->query()->firstOrCreate(['slug' => str_slug($name)], ['name' => $name]);
		return $genre;
	}

	public function create(array $input)
	{
		$genre = $this->createGenreStub($input);

		DB::transaction(function () use ($genre, $input) {
			if($genre->save()) {

				if (isset($input['image'])) {
					$image = $this->uploadCover('uploads', $input['image'], $genre);

					$genre->attachMedia($image, 'image');
				}

				return true;
			}

			throw new GeneralException(trans('exceptions.backend.music.genres.create_error'));
		});

		return $genre;
	}

	public function update(Model $genre, array $input)
	{
		$this->checkGenreByName($genre, $input['name']);
		$this->checkGenreBySlug($genre, $input['slug']);

		$genre->name = $input['name'];
		$genre->slug = (isset($input['slug']) ? $input['slug'] : str_slug($input['name']));
		$genre->description = $input['description'];

		DB::transaction(function () use ($genre, $input) {
			if($genre->save()) {

				if (isset($input['image'])) {
					if ($genre->image) {
						$genre->image->delete();
					}

					$image = $this->uploadCover('uploads', $input['image'], $genre);

					$genre->syncMedia($image, 'image');

				}

				return true;
			}

			throw new GeneralException(trans('exceptions.backend.music.genres.update_error'));
		});

		return $genre;
	}

	public function uploadCover($disk, $file, Model $genre)
	{
		$media = MediaUploader::fromSource($file)
				->toDestination($disk, $this->directory($genre))
				->useHashForFilename()
				->upload();

		return $media;
	}

	public function directory(Model $genre)
	{
		$title = title_case($genre->name);

		return 'music/covers/genres/'. $title;
	}

	public function createGenreStub($input)
	{
		$genre = self::MODEL;
		$genre = new $genre;

		$genre->name = $input['name'];
		$genre->slug = (isset($input['slug']) ? $input['slug'] : str_slug($input['name']));
		$genre->description = $input['description'];

		return $genre;
	}

	/**
     * @param  $name
     * @param  $genre
     *
     * @throws GeneralException
     */
    protected function checkGenreByName(Model $genre, $name)
    {
        //Figure out if name is not the same
        if ($genre->name != $name) {
            //Check to see if name exists
            if ($this->query()->where('name', '=', $name)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.genres.name_error'));
            }
        }
    }

    /**
     * @param  $slug
     * @param  $genre
     *
     * @throws GeneralException
     */
    protected function checkGenreBySlug(Model $genre, $slug)
    {
        //Figure out if slug is not the same
        if ($genre->slug != $slug) {
            //Check to see if slug exists
            if ($this->query()->where('slug', '=', $slug)->first()) {
                throw new GeneralException(trans('exceptions.backend.music.genres.slug_error'));
            }
        }
    }

    public function delete(Model $genre)
    {
    	$genre->delete();
    }
}