<?php 

namespace App\Repositories\Backend\Music;

use App\Repositories\BaseRepository;
use App\Models\Music\Single\Single;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Events\Backend\Music\Single\SingleCreated;
use App\Events\Backend\Music\Single\SingleUpdated;
use App\Events\Backend\Music\Single\SingleDeleted;
use App\Exceptions\GeneralException;
use App\Repositories\Backend\Music\UploadRepository;
use App\Services\Music\Tags;

class SingleRepository extends BaseRepository
{
	const MODEL = Single::class;

	protected $genres;
	protected $tracks;
	protected $upload;

	public function __construct(GenreRepository $genres, TrackRepository $tracks,
								UploadRepository $upload)
	{
		$this->genres = $genres;
		$this->tracks = $tracks;
		$this->upload = $upload;
	}

	public function create(array $input)
	{
		$files = $input['tracks'];

		foreach ($files as $file) {
			// Fetch files ID3 Tags
			if (!$tags = (new Tags($file))->getInfo())
				return false;

			$single = self::MODEL;
			$single = new $single;
			if($single->save()) {
				// Create Categories and Attach to Single instance
				$categories = $input['categories'];
				$single->categories()->attach($categories);

				// Sync Main Category
				$main_category = $input['main_category'];
				$single->categories()->syncWithoutDetaching($main_category);
				$single->categories()->updateExistingPivot($main_category, 
															['is_main' => true]);

				// Create Genres and Attach to Single instance
				$genres = $this->genres->firstOrCreate($input['genres']);
				$single->genres()->attach($genres);

				// Sync Main Genre
				$main_genre = $input['main_genre'];
				$single->genres()->syncWithoutDetaching($main_genre);
				$single->genres()->updateExistingPivot($main_genre, ['is_main' => true]);

				$media = $this->upload->audio($file, $tags, 'uploads', 
												$this->directory($single));
				
				if ($media) {
					// Create Track and Attach Media
					$track = $this->tracks->create($tags, $media, $single);
					if (!$track) {
						$single->forceDelete();
						continue;
					}
				} else {
					$single->forceDelete();
					continue;
				}
			}
		}
	}

	public function update(Model $single, array $input)
	{
		DB::transaction(function () use ($single, $input) {
			if($single->save()) {
				// Syn Categories
				$categories = $input['categories'];
				$single->categories()->sync($categories);

				// Sync Main Category
				$main_category = $input['main_category'];
				$single->categories()->syncWithoutDetaching($main_category);
				$single->categories()->updateExistingPivot($main_category, ['is_main' => true]);

				// Create Genres and Attach to Single instance
				$genres = $this->genres->firstOrCreate($input['genre_names']);
				$single->genres()->sync($genres);

				// Sync Main Genre
				$main_genre = $input['main_genre'];
				$single->genres()->syncWithoutDetaching($main_genre);
				$single->genres()->updateExistingPivot($main_genre, ['is_main' => true]);

				if ($input['track']) {
					// Store File to Storage and return Media Instance
					$file = $input['track'];

					if ($tags = (new Tags($file))->getInfo()) {
						$media = $this->upload
							->audio($file, $tags, 'uploads', $this->directory($single));

						// Create Track and Attach Media
						if ($media) {
							$track = $this->tracks->create($tags, $media, $single);
						}
					}
					
					
				}

				event(new SingleUpdated($single));

				return true;
			}
			throw new GeneralException(trans('exceptions.backend.music.singles.update_error'));
		});
		
		return $single;
	}

	public function directory(Model $single)
	{
		$category = title_case($single->main_category->name);
		$genre  =  title_case($single->main_genre->name);

		return 'music/' .  $category . '/' . $genre . '/singles';
	}

	public function delete(Model $single)
	{
		if ($single->delete()) {
			event(new SingleDeleted($single));

			return true;
		}
		throw new GeneralException(trans('exceptions.backend.music.singles.delete_error'));
		
	}
}