<?php

namespace App\Http\Requests\Backend\Music\Track;

use Illuminate\Foundation\Http\FormRequest;

class UpdateTrackRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return access()->hasRole(1);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'comment' => 'nullable|min:3|string',
            'cover' => 'nullable|mimes:jpeg,jpg,gif,png',
            'artist_names' => 'required|string|min:2|max:55',
            'features' => 'nullable|string|min:2|max:55',
            'composers' => 'nullable|string|min:2|max:55',
            'year' => 'nullable|date_format:Y',
            'number' => 'nullable|integer',
            'genre_names' => 'nullable|string|min:2|max:55',
            'copyright' => 'nullable|string|min:2|max:55',
        ];
    }
}
