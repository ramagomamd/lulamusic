<?php

namespace App\Http\Requests\Backend\Music\Album;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAlbumRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return access()->hasRole(1);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title' => 'required|string|max:191',
            'artist_name' => 'required|string|max:85',
            'description' => 'min:3|string|nullable',
            'categories' => 'required|array',
            'main_category' => 'required|exists:categories,id|integer',
            'categories.*' => 'exists:categories,id|integer',
            'genre_names' => 'required|string',
            'main_genre' => 'required|exists:genres,id|integer',
            'cover' => 'nullable|file|image',
        ];
    }
}
