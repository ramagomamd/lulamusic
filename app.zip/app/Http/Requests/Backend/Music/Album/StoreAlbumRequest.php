<?php

namespace App\Http\Requests\Backend\Music\Album;

use Illuminate\Foundation\Http\FormRequest;

class StoreAlbumRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return access()->hasRole(1);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'artist' => 'required|string|max:65',
            'description' => 'nullable|min:3|string',
            'main_category' => 'required|exists:categories,id|integer',
            'categories' => 'required|array',
            'categories.*' => 'exists:categories,id|integer',
            'genres' => 'required|string',
            'main_genre' => 'required|exists:genres,id|integer',
            'cover' => 'nullable|file|image',
        ];
    }
}
