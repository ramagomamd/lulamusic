<?php

namespace App\Http\Controllers\Backend\Music;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Music\Album\Album;
use App\Repositories\Backend\Music\AlbumRepository;
use App\Models\Music\Single\Single;
use App\Models\Music\Category\Category;
use App\Models\Music\Genre\Genre;

class ListsController extends Controller
{
    protected $albums;

    public function __construct(AlbumRepository $albums)
    {
        $this->albums = $albums;
    }

    public function albums(Category $category, Genre $genre, Request $request)
    {
        $albums  =  $this->albums->inGenre($genre->id);
    	return  view('backend.music.albums.index', compact('albums'));
    }

    public function singles(Single $single, Category $category, Genre $genre, Request $request)
    {
    	$singles = $single->where('categories', function($query) {
    		return $query->where();
    	})->where('genres', function($query) {
    		return $query->where();
    	})->get();

    	return  view('backend.music.lists.singles', compact('singles'));
    }
}
