<?php

namespace App\Http\Controllers\Backend\Music;

use App\Http\Controllers\Controller;
use App\Models\Music\Single\Single;
use App\Models\Music\Single\SingleCache;
use App\Repositories\Backend\Music\SingleRepository;
use App\Repositories\Backend\Music\CategoryRepository;
use App\Repositories\Backend\Music\GenreRepository;
use App\Http\Requests\Backend\Music\Single\ManageSingleRequest;
use App\Http\Requests\Backend\Music\Single\StoreSingleRequest;
use App\Http\Requests\Backend\Music\Single\UpdateSingleRequest;
use Illuminate\Validation\Rule;

class SinglesController extends Controller
{
    protected $singles;
    protected $cache;
    protected $categories;
    protected $genres;

    public function __construct(SingleRepository $singles, SingleCache $cache, 
        CategoryRepository $categories, GenreRepository $genres)
    {
        $this->singles = $singles;
        $this->cache = $cache;
        $this->categories = $categories;
        $this->genres = $genres;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageSingleRequest $request)
    {
        \Cache::flush();
        $title = 'All Single Tracks';
        $singles = $this->singles->query()->with('tracks.artists', 'categories', 'genres')
                    ->latest()->paginate();

        return view('backend.music.singles.index', compact('title', 'singles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageSingleRequest $request)
    {
        $categories = $this->categories->query()->orderBy('name')->get();
        $genres = $this->genres->query()->orderBy('name')->get();

        return view('backend.music.singles.create', compact('categories', 'genres'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSingleRequest $request)
    {
        $single = $this->singles->create(
            $request->only('tracks', 'categories', 'main_category', 'genres', 'main_genre'));

        return redirect()->route('admin.music.singles.index')
                ->withFlashSuccess(trans('alerts.backend.music.singles.created'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, ManageSingleRequest $request)
    {
        $single = $this->cache->get($id);
        $categories = $this->categories->query()->orderBy('name')->get();
        $genres = $this->genres->query()->orderBy('name')->get();

        return view('backend.music.singles.edit', 
                    compact('single', 'categories', 'genres'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Single $single, UpdateSingleRequest $request)
    {
        $this->cache->clear($single->id);

        $single = $this->singles->update($single, $request->only('track', 'categories', 'main_category', 'genre_names', 'main_genre'));

        $single = $this->cache->get($single->id);

        return redirect()->route('admin.music.singles.index')->withFlashSuccess(trans('alerts.backend.music.singles.updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Single $single, ManageSingleRequest $request)
    {
        $this->cache->clear($single->id);

        $this->singles->delete($single);

        return redirect()->route('admin.music.singles.index')->withFlashSuccess(trans('alerts.backend.music.singles.deleted'));
    }
}
