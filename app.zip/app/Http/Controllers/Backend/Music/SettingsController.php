<?php

namespace App\Http\Controllers\Backend\Music;

use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\Music\Setting\ManageSettingRequest;
use App\Http\Requests\Backend\Music\Setting\StoreSettingRequest;
use App\Http\Requests\Backend\Music\Setting\UpdateSettingRequest;
use App\Models\Music\Setting\Setting;

class SettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageSettingRequest $request)
    {
        $title = 'All Settings';

        return view('backend.music.settings.index', compact('title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageSettingRequest $request)
    {
        $title = 'Create A Setting';

        return view('backend.music.settings.create', compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSettingRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Setting $setting, ManageSettingRequest $request)
    {
        $title = 'View A Setting';

        return view('backend.music.settings.show', compact('title', 'setting'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Setting $setting, ManageSettingRequest $request)
    {
        $title = 'Edit A Setting';

        return view('backend.music.settings.edit', compact('title', 'setting'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSettingRequest $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Setting $setting, ManageSettingRequest $request)
    {
        //
    }
}
