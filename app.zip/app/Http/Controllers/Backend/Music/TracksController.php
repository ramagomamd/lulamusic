<?php

namespace App\Http\Controllers\Backend\Music;

use App\Models\Music\Track\Track;
use App\Models\Music\Track\TrackCache;
use App\Http\Controllers\Controller;
use App\Repositories\Backend\Music\TrackRepository;
use App\Http\Requests\Backend\Music\Track\ManageTrackRequest;
use App\Http\Requests\Backend\Music\Track\StoreTrackRequest;
use App\Http\Requests\Backend\Music\Track\UpdateTrackRequest;
use Illuminate\Validation\Rule;
use Download;

class TracksController extends Controller
{
    protected $tracks;
    protected $cache;

    public function __construct(TrackRepository $tracks, TrackCache $cache)
    {
        $this->tracks = $tracks;
        $this->cache = $cache;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageTrackRequest $request)
    {
        $title =  trans('labels.backend.music.tracks.all');
        $tracks = $this->tracks->query()->with('artists', 'trackable')->latest()->paginate();

        return view('backend.music.tracks.index', compact('title', 'tracks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageTrackRequest $request)
    {
        return view('backend.music.tracks.create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, ManageTrackRequest $request)
    {
        $track = $this->cache->get($id);

        return view('backend.music.tracks.show', compact('track'));
    }

    public function download(Track $track, ManageTrackRequest $request)
    {
        // $file = $track->file;
        // $path = $file->getAbsolutePath();
        // $filename = $track->full_title . '.' . $file->extension;
        $download = Download::fromTrack($track);
        dd($download);

        return response()->download($path, $filename);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, ManageTrackRequest $request)
    {
        $track = $this->cache->get($id);
        
        return view('backend.music.tracks.edit', compact('track'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Track $track, UpdateTrackRequest $request)
    {
        $this->cache->clear($track->id);

        $this->validate($request, [
            'title' => ['required', Rule::unique('tracks')->ignore($track->id), 'string', 'max:191'],
            'slug' => ['nullable', Rule::unique('tracks')->ignore($track->id), 'alpha_dash', 'max:191'],
        ]);

        $track = $this->tracks->update($track, $request->all());
        $track = $this->cache->get($track->id);

        return redirect()->route('admin.music.tracks.show', $track)
                            ->withFlashSuccess(trans('alerts.backend.music.tracks.updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Track $track, ManageTrackRequest $request)
    {
        $this->cache->clear($track->id);

        $this->tracks->delete($track);

        return redirect()->route('admin.music.tracks.index')->withFlashSuccess(trans('alerts.backend.music.tracks.deleted'));
    }
}
