<?php

namespace App\Http\Controllers\Backend\Music;

use App\Http\Controllers\Controller;
use App\Models\Music\Genre\Genre;
use App\Models\Music\Genre\GenreCache;
use App\Repositories\Backend\Music\GenreRepository;
use App\Repositories\Backend\Music\TrackRepository;
use App\Http\Requests\Backend\Music\Genre\ManageGenreRequest;
use App\Http\Requests\Backend\Music\Genre\StoreGenreRequest;
use App\Http\Requests\Backend\Music\Genre\UpdateGenreRequest;
use Illuminate\Validation\Rule;

class GenresController extends Controller
{
    protected $genres;
    protected $tracks;
    protected $cache;

    public function __construct(GenreRepository $genres, GenreCache $cache, TrackRepository $tracks)
    {
        $this->genres = $genres;
        $this->tracks = $tracks;
        $this->cache = $cache;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageGenreRequest $request)
    {
        $genres = $this->genres->query()->orderBy('name')->paginate();

        return view('backend.music.genres.index', compact('genres'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageGenreRequest $request)
    {
        return view('backend.music.genres.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreGenreRequest $request)
    {
        $genre = $this->genres->create($request->only('name', 'slug', 'description'));

        $genre = $this->cache->get($genre->id);

        return redirect()->route('admin.music.genres.show', compact('genre'))
                ->withFlashSuccess(trans('alerts.backend.music.genres.created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, ManageGenreRequest $request)
    {
        $genre = $this->cache->get($id);
         
        $albums = $genre->albums();
        $albums_count = $albums->count();
        $albums = $albums->with('artist', 'categories', 'genres')->withCount('tracks')->take(5)->get();

        $singles = $genre->singles();
        $singles_count = $singles->count();
        $singles= $singles->with('tracks.artists', 'categories', 'genres')->take(5)->get();

        return view('backend.music.genres.show', 
                        compact('genre', 'albums', 'singles', 'albums_count', 'singles_count'));
    }

    public function albums($id)
    {
        $genre = $this->cache->get($id);
        $title = 'All ' . $genre->name . ' Genre Albums';
        $albums = $genre->albums()->with('artist')->latest()->paginate(); 

        return  view('backend.music.albums.index', compact('title', 'albums'));
    }

    public function singles($id)
    {
        $genre = $this->cache->get($id);
        $title = 'All ' . $genre->name . ' Genre Singles';
        $singles = $genre->singles()->with('tracks.artists', 'categories', 'genres')
                    ->latest()->paginate();

        return  view('backend.music.singles.index', compact('title', 'singles'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, ManageGenreRequest $request, GenreCache $cache)
    {
        $genre = $this->cache->get($id);

        return view('backend.music.genres.edit', compact('genre'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Genre $genre, UpdateGenreRequest $request)
    {
        $this->cache->clear($genre->id);

        $this->validate($request, [
            'name' => ['required', Rule::unique('genres')->ignore($genre->id), 'string', 'max:85'],
            'slug' => ['nullable', Rule::unique('genres')->ignore($genre->id), 'alpha_dash', 'max:85'],
        ]);

        $genre = $this->genres->update($genre, $request->only('name', 'slug', 'description'));

        $genre = $this->cache->get($genre->id);

        return redirect()->route('admin.music.genres.show', $genre)->withFlashSuccess(trans('alerts.backend.music.genres.updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Genre $genre, ManageGenreRequest $request)
    {
        $this->cache->clear($genre->id);

        $this->genres->delete($genre);

        return redirect()->route('admin.music.genres.index')->withFlashSuccess(trans('alerts.backend.music.genres.deleted'));
    }
}
