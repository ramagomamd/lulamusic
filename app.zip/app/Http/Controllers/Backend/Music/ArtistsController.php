<?php

namespace App\Http\Controllers\Backend\Music;

use App\Http\Controllers\Controller;
use App\Models\Music\Artist\Artist;
use App\Models\Music\Artist\ArtistCache;
use App\Repositories\Backend\Music\ArtistRepository;
use App\Http\Requests\Backend\Music\Artist\ManageArtistRequest;
use App\Http\Requests\Backend\Music\Artist\StoreArtistRequest;
use App\Http\Requests\Backend\Music\Artist\UpdateArtistRequest;
use Illuminate\Validation\Rule;

class ArtistsController extends Controller
{
    protected $artists;
    protected $cache;

    public function __construct(ArtistRepository $artists, ArtistCache $cache)
    {
        $this->artists = $artists;
        $this->cache = $cache;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageArtistRequest $request)
    {
        $artists = $this->artists->query()->orderBy('name')->paginate();

        return view('backend.music.artists.index', compact('artists'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageArtistRequest $request)
    {
        return view('backend.music.artists.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreArtistRequest $request)
    {
        $artist = $this->artists->create($request->only('name', 'slug', 'bio', 'image'));

        $artist = $this->cache->get($artist->id);

        return redirect()->route('admin.music.artists.show', compact('artist'))
                ->withFlashSuccess(trans('alerts.backend.music.artists.created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, ManageArtistRequest $request)
    {
        $artist = $this->cache->get($id);

        $albums = $this->artists->albums($artist);
        $albums_count = $albums->count();
        $albums = $albums->with('artist', 'categories', 'genres')
                    ->withCount('tracks')->latest()->take(6)->get();

        $tracks = $artist->singles;
        $tracks_count = $tracks->count();
        $tracks = $tracks->with('artists', 'trackable.categories', 'trackable.genres')
                            ->latest()->take(6)->get();

        return view('backend.music.artists.show', 
                        compact('artist', 'albums', 'tracks', 'albums_count', 'tracks_count'));
    }

    public function albums($id)
    {
        $artist = $this->cache->get($id);
        $title = 'All ' . $artist->name . ' Albums';
        $albums = $this->artists->albums($artist)->with('artist')->latest()->paginate(); 

        return  view('backend.music.albums.index', compact('title', 'albums'));
    }

    public function singles($id)
    {
        $artist = $this->cache->get($id);
        $title = 'All ' . $artist->name . ' Singles';
        $tracks = $artist->singles->with('artists', 'trackable.categories', 'trackable.genres')
                    ->latest()->paginate();

        return  view('backend.music.artists.singles', compact('title', 'tracks'));
    }

    public function tracks($id)
    {
        $genre = $this->cache->get($id);
        $title = 'All ' . $genre->name . ' Genre Singles';
        $singles = $genre->singles()->with('tracks.artists', 'categories', 'genres')
                    ->latest()->paginate(); 

        return  view('backend.music.singles.index', compact('title', 'singles'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, ManageArtistRequest $request)
    {
        $artist = $this->cache->get($id);

        return view('backend.music.artists.edit', compact('artist'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Artist $artist, UpdateArtistRequest $request)
    {
        $this->cache->clear($artist->id);

        $this->validate($request, [
            'name' => ['required', Rule::unique('artists')->ignore($artist->id), 'string', 'max:85'],
            'slug' => ['nullable', Rule::unique('artists')->ignore($artist->id), 'alpha_dash', 'max:85'],
        ]);

        $artist = $this->artists->update($artist, $request->only('name', 'slug', 'bio', 'image'));

        $artist = $this->cache->get($artist->id);

        return redirect()->route('admin.music.artists.show', $artist)
                ->withFlashSuccess(trans('alerts.backend.music.artists.updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Artist $artist, ManageArtistRequest $request)
    {
        $this->cache->clear($artist->id);

        $this->artists->delete($artist);

        return redirect()->route('admin.music.artists.index')->withFlashSuccess(trans('alerts.backend.music.artists.deleted'));
    }
}
