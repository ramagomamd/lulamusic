<?php

namespace App\Http\Controllers\Backend\Music;

use App\Http\Controllers\Controller;
use App\Models\Music\Category\Category;
use App\Models\Music\Category\CategoryCache;
use App\Repositories\Backend\Music\CategoryRepository;
use App\Http\Requests\Backend\Music\Category\ManageCategoryRequest;
use App\Http\Requests\Backend\Music\Category\StoreCategoryRequest;
use App\Http\Requests\Backend\Music\Category\UpdateCategoryRequest;
use Illuminate\Validation\Rule;

class CategoriesController extends Controller
{
    protected $categories;
    protected $cache;

    public function __construct(CategoryRepository $categories, CategoryCache $cache)
    {
        $this->categories = $categories;
        $this->cache = $cache;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageCategoryRequest $request)
    {
        $categories = $this->categories->query()->orderBy('name')->paginate();

        return view('backend.music.categories.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageCategoryRequest $request)
    {
        $categories = $this->categories->query()->orderBy('name')->get();

        return view('backend.music.categories.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCategoryRequest $request)
    {
        $category = $this->categories->create($request->only('name', 'slug', 'description', 'category_id'));

        $category = $this->cache->get($category->id);

        return redirect()->route('admin.music.categories.show', $category->id)
                ->withFlashSuccess(trans('alerts.backend.music.categories.created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, ManageCategoryRequest $request)
    {
        $category = $this->cache->get($id);
         
        $albums = $category->albums();
        $albums_count = $albums->count();
        $albums = $albums->with('artist', 'categories', 'genres')->withCount('tracks')->take(5)->get();

        $singles = $category->singles();
        $singles_count = $singles->count();
        $singles= $singles->with('tracks.artists', 'categories', 'genres')->take(5)->get();

        return view('backend.music.categories.show', 
                        compact('category', 'albums', 'singles', 'albums_count', 'singles_count'));
    }

    public function albums($id)
    {
        $category = $this->cache->get($id);
        $title = 'All ' . $category->name . ' Category Albums';
        $albums = $category->albums()->with('artist')->latest()->paginate(); 

        return  view('backend.music.albums.index', compact('title', 'albums'));
    }

    public function singles($id)
    {
        $category = $this->cache->get($id);
        $title = 'All ' . $category->name . ' Category Singles';
        $singles = $category->singles()->with('tracks.artists', 'categories', 'genres')
                    ->latest()->paginate(); 

        return  view('backend.music.singles.index', compact('title', 'singles'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, ManageCategoryRequest $request)
    {
        $category = $this->cache->get($id);
        $categories = $this->categories->query()->orderBy('name')->get();
        $categories = $categories->reject(function($value) use ($id) {
            return $value->id === $id;
        }); 
        $parent = $category->ancestors->last();

        return view('backend.music.categories.edit', compact('category', 'parent', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Category $category, UpdateCategoryRequest $request)
    {
        $this->cache->clear($category->id);

        $this->validate($request, [
            'name' => ['required', Rule::unique('categories')->ignore($category->id), 'string', 'min:2', 'max:191'],
            'slug' => ['nullable', Rule::unique('categories')->ignore($category->id), 'alpha_dash', 'min:2', 'max:191'],
        ]);

        $category = $this->categories->update($category, $request->only(
                                                    'name', 'slug', 'description', 'category_id'
                                            )
        );

        $category = $this->cache->get($category->id);

        return redirect()->route('admin.music.categories.show', $category)
                ->withFlashSuccess(trans('alerts.backend.music.categories.updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category, ManageCategoryRequest $request)
    {
        $this->cache->clear($category->id);

        $this->categories->delete($category);

        return redirect()->route('admin.music.categories.index')->withFlashSuccess(trans('alerts.backend.music.categories.deleted'));
    }
}
