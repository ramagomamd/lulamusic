<?php

namespace App\Http\Controllers\Backend\Music;

use App\Http\Controllers\Controller;
use App\Models\Music\Album\Album;
use App\Models\Music\Album\AlbumCache;
use App\Repositories\Backend\Music\AlbumRepository;
use App\Repositories\Backend\Music\CategoryRepository;
use App\Repositories\Backend\Music\GenreRepository;
use App\Http\Requests\Backend\Music\Album\ManageAlbumRequest;
use App\Http\Requests\Backend\Music\Album\StoreAlbumRequest;
use App\Http\Requests\Backend\Music\Album\UpdateAlbumRequest;
use App\Http\Requests\Backend\Music\Album\UploadTracksRequest;
use Download;

class AlbumsController extends Controller
{
    protected $albums;
    protected $cache;
    protected $categories;
    protected $genres;

    public function __construct(AlbumRepository $albums, CategoryRepository $categories,
                    GenreRepository  $genres, AlbumCache $cache)
    {
        $this->albums = $albums;
        $this->cache = $cache;
        $this->categories = $categories;
        $this->genres = $genres;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ManageAlbumRequest $request)
    {
        $title = trans('labels.backend.music.albums.all');
        $albums = $this->albums->query()->with('artist', 'tracks', 'categories', 'genres')
                            ->withCount('tracks')->latest()->paginate();

        return view('backend.music.albums.index', compact('title', 'albums'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(ManageAlbumRequest $request)
    {
        $categories = $this->categories->query()->orderBy('name')->get();
        $genres = $this->genres->query()->orderBy('name')->get();

        return view('backend.music.albums.create', compact('categories', 'genres'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAlbumRequest $request)
    {      
        $album = $this->albums->create($request->only(
                                        'artist', 'title', 'description', 'main_category', 
                                        'categories', 'cover', 'main_genre', 'genres'
                                        )
                );

        $album = $this->cache->get($album->id);

        return redirect()->route('admin.music.albums.show', compact('album'))
                ->withFlashSuccess(trans('alerts.backend.music.albums.created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, ManageAlbumRequest $request)
    {
        \Cache::flush();
        $album = $this->cache->get($id);
        $tracks = $album->tracks()->with('artists', 'trackable')->latest()->paginate();

        return view('backend.music.albums.show', compact('album', 'tracks'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id, ManageAlbumRequest $request)
    {
        $album = $this->cache->get($id);
        $categories = $this->categories->query()->orderBy('name')->get();
        $genres = $this->genres->query()->orderBy('name')->get();

        return view('backend.music.albums.edit', compact('album', 'categories','genres'));
    }

    public function upload(UploadTracksRequest $request)
    {
        $this->cache->clear($request->get('album_id'));

        $album = $this->albums->upload($request->only('tracks', 'album_id'));
        $album = $this->cache->get($album->id);

        return redirect()->route('admin.music.albums.show', $album)
                ->withFlashSuccess(trans('alerts.backend.music.albums.uploaded_tracks'));
    }

    public function download(Album $album, ManageAlbumRequest $requests)
    {
        $zip = Download::from($album);

        return response()->download($zip);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Album $album, UpdateAlbumRequest $request)
    {
        $this->cache->clear($album->id);

        $this->albums->update($album, $request->only(
                                        'artist_name', 'title','description', 'categories', 
                                        'main_category', 'genre_names', 'main_genre', 'cover'
                                    )
        );

        $album = $this->cache->get($album->id);

        return redirect()->route('admin.music.albums.show', $album)
                ->withFlashSuccess(trans('alerts.backend.music.albums.updated'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Album $album, ManageAlbumRequest $requests)
    {
        $this->cache->clear($album->id);

        $this->albums->delete($album);

        return redirect()->route('admin.music.albums.index')
                ->withFlashSuccess(trans('alerts.backend.music.albums.deleted'));
    }
}
