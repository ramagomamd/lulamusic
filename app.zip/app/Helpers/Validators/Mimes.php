<?php

namespace App\Helpers\Validators;

/**
 * Class Mimes.
 */
class Mimes
{
    public function audio($file)
    {
        $extensions = collect([
                'aac',
                'ogg',
                'oga',
                'mp3',
                'mpga',
                'wav',
                'aif',
                'aifc',
                'aiff',
                'au',
                'funk',
                'it',
                'jam',
                'kar',
                'la',
                'lam',
                'lma',
                'm2a',
                'm3u',
                'mid',
                'midi',
                'mjf',
                'mod',
                'mp2',
                'mpa',
                'mpg',
                'my',
                'pfunk',
                'qcp',
                'ra',
                'ram',
                'rm',
                'rmi',
                'rmm',
                'rmp',
                'rng',
                'sid',
                'snd',
                'tsi',
                'voc',
                'vox',
                'vqe',
                'vqf',
                'vql',
        ]);

        $extension = $file->extension();

        if ($extensions->contains($extension)) {
            return true;
        }
        return false;
    }

    public function image($file)
    {
        $extensions = collect([
                'jpg',
                'jpeg',
                'png',
                'gif',
        ]);

        $extension = $file->extension();

        if ($extensions->contains($extension)) {
            return true;
        }
        return false;
    }
}
